(function() {
	"use strict";
	
	chrome.runtime.onMessage.addListener(
		function(request, sender, sendResponse) {
			if(request.action === "getOutput") {
				wadget(sendResponse);
				return true;
			}
		}
	);
	
	function wadget(sendResponse) {
		chrome.tabs.query(
			{ active: true, lastFocusedWindow: true },
			function(tabs) {
				var url = tabs[0].url;
				if(url.startsWith("https://") || url.startsWith("http://")) {
					var urlObj = new URL(tabs[0].url);
					if(urlObj.hostname.includes("books.google")) {
						book(sendResponse, urlObj);
					} else {
						newspaper(sendResponse, urlObj, tabs[0].title);
					}
				} else { sendResponse(""); }
			}
		);
	}
	
	function book(sendResponse, urlObj) {
		// ------------ //
		// --- BOOK --- //
		// ------------ //
		
		var bookId = urlObj.searchParams.get("id");
		var pageUrl = urlObj.searchParams.get("pg") || "xxx";
		var pageNum = (pageUrl.match(/[0-9]+/) || ["xxx"])[0];
		fetch("https://www.googleapis.com/books/v1/volumes/" + bookId)
			.then(function(response) { return response.json(); })
			.then(function(response) {
				// --- BOOK DETAILS --- //
				var author = (response.volumeInfo.authors || []).join(", ");
				var title = response.volumeInfo.title.replace(/\|/g, "-");
				var publisher = (response.volumeInfo.publisher || "").replace(/\|/g, "-");
				var dateOfPub = (response.volumeInfo.publishedDate || "")
					.match(/^[0-9]{4}/) || "";
				if(dateOfPub) { dateOfPub = dateOfPub[0]; }
				
				// --- ISBN --- //
				function hyphenateISBN(isbn) {
					var prefix = "";
					if(isbn.length === 13) {
						prefix = isbn.substring(0, 3) + "-";
						isbn = isbn.substring(3, 13);
					}
					
					if(parseInt(isbn.substring(0, 1)) === 3) {
						var regex, d = parseInt(isbn.substring(1, 3));
						if(d < 20) {
							regex = /([0-9])([0-9]{2})([0-9]{6})(\w)/;
						} else if(d < 70) {
							regex = /([0-9])([0-9]{3})([0-9]{5})(\w)/;
						} else if(d < 85) {
							regex = /([0-9])([0-9]{4})([0-9]{4})(\w)/;
						} else if(d < 90) {
							regex = /([0-9])([0-9]{5})([0-9]{3})(\w)/;
						} else if(d < 95) {
							regex = /([0-9])([0-9]{6})([0-9]{2})(\w)/;
						} else if(d <= 99) {
							regex = /([0-9])([0-9]{7})([0-9])(\w)/;
						}
						
						if(regex) {
							isbn = prefix + isbn.replace(regex, "$1-$2-$3-$4");
						}
						return isbn;
					}
					return false;
				}
				var isbn = response.volumeInfo.industryIdentifiers || "";
				if(isbn) {
					if(isbn[0].type === "ISBN_13") {
						isbn = hyphenateISBN(isbn[0].identifier);
					} else if(isbn[1] && isbn[1].type === "ISBN_13") {
						isbn = hyphenateISBN(isbn[1].identifier);
					} else { isbn = ""; }
				}
				
				// --- DONE --- //
				var output =
					"„xxx“" +
					"<ref>{{Literatur" +
					(author ? "|Autor=" + author : "") +
					"|Titel=" + title +
					(publisher ? "|Verlag=" + publisher : "") +
					(dateOfPub ? "|Jahr=" + dateOfPub : "") +
					"|Seiten=" + pageNum +
					(isbn ? "|ISBN=" + isbn : "") +
					"|Online=Zitiert nach " +
					"{{GBS|" + bookId + "|" + pageUrl + "|Hervorhebung=\"xxx\"}}" +
					"}}</ref>";
				sendResponse(output);
			}).catch(function(error) {
				sendResponse("Ein Fehler ist aufgetreten.");
				console.log(error);
			});
	}
	
	function newspaper(sendResponse, urlObj, title) {
		// ----------------- //
		// --- NEWSPAPER --- //
		// ----------------- //
		
		chrome.tabs.executeScript({
			code: "[document.all[0].outerHTML, window.getSelection().toString()]"
		}, function(data) {
			var html = new DOMParser().parseFromString(data[0][0], "text/html");
			
			var exampleSentence = data[0][1]
				.replace(/„/g, "‚")
				.replace(/“/g, "‘")
				.replace(/"/g, "'") || "xxx";
			exampleSentence = "„" + exampleSentence + "“";
			
			// --- WEBSITE/TEMPLATE NAME --- //
			var site = urlObj.hostname;
			var link = "|Online=" + urlObj.href;
			var recognizedSite = false;
			var siteNames = {
				"sueddeutsche.de": "Süddeutsche",
				"tagesspiegel.de": "Tagesspiegel",
				"spiegel.de": "Spiegel",
				"merkur.de": "Merkur",
				"focus.de": "Focus",
				"stern.de": "Stern",
				"bild.de": "Bild",
				"welt.de": "Welt",
				"faz.net": "FAZ",
				"nzz.ch": "NZZ",
				"taz.de": "taz"
			};
			for(let i in siteNames) {
				if(site.includes(i)) {
					site = siteNames[i];
					recognizedSite = true;
					break;
				}
			}
			
			if(recognizedSite) {
				// --- AUTHOR --- //
				var author;
				function getText(element, metatag) {
					if(metatag) {
						return (element ? element.getAttribute("content").trim() : "");
					}
					return (element ? element.textContent.trim() : "");
				}
				switch(site) {
					case "Bild":
						author = getText(html.querySelector(".authors__name"), false);
						author = author.toLowerCase().replace(
							// fix names written in all uppercase
							/(?<=\s|-|^)([a-zA-ZäöüÄÖÜß])/g,
							function(i) { return i.toUpperCase(); }
						);
						break;
					case "FAZ":
						author = getText(html.querySelector(
							".atc-MetaAuthor, .atc-MetaAuthorLink"
						), false);
						break;
					case "Focus":
						author = getText(html.querySelector("span[itemprop='author']"), false);
						break;
					case "Merkur":
						author = getText(html.querySelector(
							"meta[property='lp.article:author']"
						), true);
						break;
					case "NZZ":
					case "Spiegel":
					case "Süddeutsche":
					case "taz":
						author = getText(html.querySelector("meta[name='author']"));
						author = author
							.replace(", DER SPIEGEL", "")
							.replace("DER SPIEGEL", "");
						break;
					case "Stern":
						author = "";
						break;
					case "Tagesspiegel":
						author = getText(html.querySelector(".ts-author"), false);
						break;
					case "Welt":
						author = getText(html.querySelector(".c-author__by-line"), false);
						author = author.replace("Von", "").trim();
						break;
				}
				author = (author ? "|Autor=" + author : "");
				
				// --- PAGE TITLE --- //
				title = "|Titel=" + title.replace(/\|/g, "-");
				
				// --- PUBLICATION DATE --- //
				var dateOfPub;
				if(["Bild", "FAZ", "Süddeutsche", "Tagesspiegel"].includes(site)) {
					if(site === "Bild") {
						dateOfPub = html.querySelector("time.authors__pubdate");
					} else if(site === "FAZ") {
						dateOfPub = html.querySelector("time.atc-MetaTime");
					} else if(site === "Süddeutsche") {
						dateOfPub = html.querySelector(".sz-article__header > time");
					} else if(site === "Tagesspiegel") {
						dateOfPub = html.querySelector("time[itemprop='datePublished']");
					}
					dateOfPub = (dateOfPub ? dateOfPub.getAttribute("datetime") : "");
				} else {
					dateOfPub = html.querySelector(
						"meta[property='article:published_time'], meta[name='date']"
					);
					dateOfPub = (dateOfPub ? dateOfPub.getAttribute("content") : "");
				}
				dateOfPub = dateOfPub.match(/^([0-9]{4})-([0-9]{2})-([0-9]{2})/) || "";
				if(dateOfPub) {
					dateOfPub =
						"|Tag=" + dateOfPub[3] +
						"|Monat=" + dateOfPub[2] +
						"|Jahr=" + dateOfPub[1];
				}
				
				// --- DATE OF ACCESS --- //
				var dateOfAccess = new Date();
				dateOfAccess = "|Zugriff=" +
					dateOfAccess.getFullYear() + "-" +
					String(dateOfAccess.getMonth() + 1).padStart(2, "0") + "-" +
					String(dateOfAccess.getDate()).padStart(2, "0");
				
				// --- DONE --- //
				var output =
					exampleSentence +
					"<ref>{{Per-" + site + " Online" +
					link + author + title + dateOfPub + dateOfAccess +
					"}}</ref>";
				sendResponse(output);
			} else {
				sendResponse("Diese Seite kann leider nicht zitiert werden.");
			}
		});
	}
})();
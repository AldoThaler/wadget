(function() {
	"use strict";
	
	var query = "",
		quickCiteState = false,
		quickCiteLink = "",
		siteNames = {
			"books.google": "Google Books",
			"sueddeutsche.de": "Süddeutsche",
			"tagesspiegel.de": "Tagesspiegel",
			"spiegel.de": "Spiegel",
			"merkur.de": "Merkur",
			"focus.de": "Focus",
			"stern.de": "Stern",
			"bild.de": "Bild",
			"welt.de": "Welt",
			"faz.net": "FAZ",
			"nzz.ch": "NZZ",
			"taz.de": "taz"
		};
	
	chrome.runtime.onMessage.addListener(
		function(request, sender, sendResponse) {
			if(request.action === "getOutput") {
				if(quickCiteState) {
					// quick cite is turned on
					cite(quickCiteLink, sendResponse);
				} else {
					chrome.tabs.query(
						{ active: true, lastFocusedWindow: true },
						function(tabs) { cite(tabs[0].url, sendResponse); }
					);
				}
				return true;
			}
		}
	);
	
	function cite(url, sendResponse) {
		// check if site is recognized
		var site = new URL(url).hostname;
		var recognized = false;
		for(let i in siteNames) {
			if(site.includes(i)) {
				site = siteNames[i];
				recognized = true;
				break;
			}
		}
		if(!recognized) { site = false; }
		
		if(site) {
			if(site === "Google Books") {
				citeBook(url, sendResponse);
			} else {
				citeNewspaper(url, site, sendResponse);
			}
		} else {
			// bad site
			var newspapers = Object.values(siteNames).slice(1).join(", ");
			sendResponse({
				state: "error",
				data: "Diese Seite wird leider nicht anerkannt. " +
					"Du kannst nur aus Büchern bei Google Books zitieren " +
					"oder aus folgenden Online-Zeitungen: " + newspapers
			});
		}
	}
	
	// ------------------ //
	// --- QUICK CITE --- //
	// ------------------ //
	
	chrome.runtime.onInstalled.addListener(function() {
		chrome.contextMenus.create({
			"id": "quick-cite",
			"title": "Werk zitieren",
			"contexts": ["link"]
		});
		chrome.contextMenus.create({
			"id": "quick-cite-query",
			"title": "Suchbegriff markieren",
			"contexts": ["selection"]
		});
	});
	
	chrome.contextMenus.onClicked.addListener(function(info) {
		if(info.menuItemId === "quick-cite") {
			quickCiteState = true;
			quickCiteLink = info.linkUrl;
		} else if(info.menuItemId === "quick-cite-query") {
			query = info.selectionText;
		}
	});
	
	// ------------ //
	// --- BOOK --- //
	// ------------ //
	
	function citeBook(url, sendResponse) {
		var urlObj = new URL(url),
			bookId = urlObj.searchParams.get("id");
		
		if(!bookId) {
			sendResponse({
				state: "error",
				data: "Es wurde kein zu zitierendes Buch gefunden."
			});
			return false;
		}
		
		fetch("https://www.googleapis.com/books/v1/volumes/" + bookId)
			.then(function(response) { return response.json(); })
			.then(function(response) {
				if(!response.volumeInfo) {
					sendResponse({
						state: "error",
						data: "Ein Fehler ist aufgetreten."
					});
					return false;
				}
				
				// --- BOOK DETAILS --- //
				var author = (response.volumeInfo.authors || []).join(", ");
				var title = response.volumeInfo.title.replace(/\|/g, "-");
				var publisher = (response.volumeInfo.publisher || "").replace(/\|/g, "-");
				var dateOfPub = (response.volumeInfo.publishedDate || "")
					.match(/^[0-9]{4}/) || "";
				if(dateOfPub) { dateOfPub = dateOfPub[0]; }
				
				// --- ISBN --- //
				function hyphenateISBN(isbn) {
					var prefix = "";
					if(isbn.length === 13) {
						prefix = isbn.substring(0, 3) + "-";
						isbn = isbn.substring(3, 13);
					}
					
					if(parseInt(isbn.substring(0, 1)) === 3) {
						var regex, d = parseInt(isbn.substring(1, 3));
						if(d < 20) {
							regex = /([0-9])([0-9]{2})([0-9]{6})(\w)/;
						} else if(d < 70) {
							regex = /([0-9])([0-9]{3})([0-9]{5})(\w)/;
						} else if(d < 85) {
							regex = /([0-9])([0-9]{4})([0-9]{4})(\w)/;
						} else if(d < 90) {
							regex = /([0-9])([0-9]{5})([0-9]{3})(\w)/;
						} else if(d < 95) {
							regex = /([0-9])([0-9]{6})([0-9]{2})(\w)/;
						} else if(d <= 99) {
							regex = /([0-9])([0-9]{7})([0-9])(\w)/;
						}
						
						if(regex) {
							isbn = prefix + isbn.replace(regex, "$1-$2-$3-$4");
						}
						return isbn;
					}
					return false;
				}
				var isbn = response.volumeInfo.industryIdentifiers || "";
				if(isbn) {
					if(isbn[0].type === "ISBN_13") {
						isbn = hyphenateISBN(isbn[0].identifier);
					} else if(isbn[1] && isbn[1].type === "ISBN_13") {
						isbn = hyphenateISBN(isbn[1].identifier);
					} else { isbn = ""; }
				}
				
				// --- PAGE NUMBER --- //
				var pageUrl = urlObj.searchParams.get("pg");
				var pageNum = pageUrl.match(/(?:PA|PT|PP|PG)([0-9]+)/);
				pageNum = (pageNum ? pageNum[1] : "xxx");
				var output =
					"„xxx“" +
					"<ref>{{Literatur" +
					(author ? "|Autor=" + author : "") +
					"|Titel=" + title +
					(publisher ? "|Verlag=" + publisher : "") +
					(dateOfPub ? "|Jahr=" + dateOfPub : "") +
					"|Seiten=" + pageNum +
					(isbn ? "|ISBN=" + isbn : "") +
					"|Online=Zitiert nach " +
					"{{GBS|" + bookId +
						(pageUrl ? "|" + pageUrl : "") +
						"|Hervorhebung=\"" +
						(query ? query : "xxx") + "\"}}" +
					"}}</ref>";
				sendResponse({ state: "success", data: output });
				quickCiteState = false;
			}).catch(function(error) {
				sendResponse({
					state: "error",
					data: "Ein Fehler ist aufgetreten."
				});
				quickCiteState = false;
				console.log(error);
			});
	}
	
	// ----------------- //
	// --- NEWSPAPER --- //
	// ----------------- //
	
	function citeNewspaper(url, site, sendResponse) {
		var html = {},
			exampleSentence = "",
			urlObj = new URL(url);
		
		function escapeRegExp(str) {
			return str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
		}
		
		// --- EXAMPLE SENTENCE --- //
		if(quickCiteState) {
			fetch(url)
				.then(function(data) {
					return data.text();
				}).then(function(data) {
					html = new DOMParser().parseFromString(data, "text/html");
					if(query) {
						// fetch all paragraphs
						var paragraphs = [];
						switch(site) {
							case "Bild":
								paragraphs = html.querySelectorAll(
									"article > .txt > p"
								);
								break;
							case "FAZ":
								if(urlObj.hostname === "blogs.faz.net") {
									paragraphs = html.querySelectorAll(
										"article .single-entry-content > p"
									);
								} else {
									paragraphs = html.querySelectorAll(
										"article .atc-Intro > p, article .atc-Text > p"
									);
								}
								break;
							case "Focus":
								if(urlObj.hostname === "praxistipps.focus.de") {
									paragraphs = html.querySelectorAll(
										".Article .Article__Intro," +
										".Article .Article__Text," +
										".Article ul.List"
									);
								} else {
									paragraphs = html.querySelectorAll(
										"#article .articleContent > .leadIn > p," +
										"#article .articleContent > .textBlock > p"
									);
								}
								break;
							case "Merkur":
								paragraphs = html.querySelectorAll(
									"article > .id-Article-body p.id-Article-content-item"
								);
								break;
							case "NZZ":
								paragraphs = html.querySelectorAll(
									"section.container--article > p"
								);
								break;
							case "Spiegel":
								paragraphs = html.querySelectorAll(
									"article div.RichText > p"
								);
								break;
							case "Stern":
								paragraphs = html.querySelectorAll(
									"article > .article-content > .rtf-content-wrapper > p"
								);
								break;
							case "Süddeutsche":
								paragraphs = html.querySelectorAll(
									"article > div[itemprop='articleBody'] > p"
								);
								break;
							case "Tagesspiegel":
								paragraphs = html.querySelectorAll(
									"article .ts-article-body > p"
								);
								break;
							case "taz":
								paragraphs = html.querySelectorAll(
									"article > p.article"
								);
								break;
							case "Welt":
								paragraphs = html.querySelectorAll(
									"article div[itemprop='articleBody'] > p"
								);
								break;
						}
						
						var text = "";
						for(let i = 0; i < paragraphs.length; i++) {
							text += paragraphs[i].textContent.trim() + " ";
						}
						text = text.replace(/[\r\n]/g, " ");
						// fetch sentence containing the query
						exampleSentence = (text.match(new RegExp(
							"(?:[A-ZÄÖÜ][^.!?]*[^-]|^)" +
							escapeRegExp(query) +
							"(?!-|[a-zäöü]).*?[.!?]"
						)) || [""])[0];
						if(exampleSentence) { exec(); } else {
							// example not found
							sendResponse({
								state: "error",
								data: "Der Suchbegriff konnte im Artikel " +
									"leider nicht gefunden werden."
							});
						}
					} else { exec(); }
					quickCiteState = false;
				}).catch(function(error) {
					sendResponse({
						state: "error",
						data: "Ein Fehler ist aufgetreten."
					});
					quickCiteState = false;
					console.log(error);
				});
		} else {
			chrome.tabs.executeScript({
				code: "[document.all[0].outerHTML, window.getSelection().toString()]"
			}, function(data) {
				html = new DOMParser().parseFromString(data[0][0], "text/html");
				exampleSentence = data[0][1].trim();
				exec();
			});
		}
		
		function exec() {
			exampleSentence =
				"„" + (exampleSentence || "xxx")
					.replace(/[„"](.*?)[“"]/g, "‚$1‘")
					.replace(/[\r\n]+/g, " ") + "“";
			if(query) {
				exampleSentence = 
					exampleSentence.replace(
						// automatically italicize query
						new RegExp(
							"([^-]|^)(" +
							escapeRegExp(query) +
							")(?!-|[a-zäöü])", "g"
						), "$1''$2''"
					);
			}
			
			var link = "|Online=" + url;
			function getText(element, metatag) {
				var val = "";
				if(metatag) {
					val = (element ? element.getAttribute("content") : "");
				} else {
					val = (element ? element.textContent : "");
				}
				val = val.trim().replace(/\|/g, "-");
				return val;
			}
			
			// --- AUTHOR --- //
			var author = "";
			switch(site) {
				case "Bild":
					author = getText(html.querySelector(
						".authors__name"
					), false);
					break;
				case "FAZ":
					if(urlObj.hostname === "blogs.faz.net") {
						author = getText(html.querySelector(
							"header .entry-author a"
						), false);
					} else {
						author = getText(html.querySelector(
							".atc-MetaAuthor, .atc-MetaAuthorLink"
						), false);
					}
					break;
				case "Focus":
					author = getText(html.querySelector(
						"span[itemprop='author'], a[rel='author']"
					), false);
					break;
				case "Merkur":
					author = getText(html.querySelector(
						"meta[property='lp.article:author']"
					), true);
					break;
				case "NZZ":
				case "Spiegel":
				case "Süddeutsche":
				case "taz":
					if(urlObj.hostname === "blogs.taz.de") {
						author = getText(html.querySelector(
							"p.author span"
						), false);
					} else {
						author = getText(html.querySelector(
							"meta[name='author']"
						), true);
						
						if(author.startsWith("DER SPIEGEL")) { author = ""; }
						if(author === "Süddeutsche Zeitung") { author = ""; }
					}
					break;
				case "Stern":
					author = getText(html.querySelector(
						".o-author-introduction li .content .name"
					), false);
					break;
				case "Tagesspiegel":
					author = getText(html.querySelector(
						".ts-author"
					), false);
					break;
				case "Welt":
					author = getText(html.querySelector(
						".c-author__by-line"
					), false);
					author = author.replace(/^Von/, "").trim();
					break;
			}
			author = (author.match(/[a-zA-ZäöüÄÖÜß\-\s]+/, "") || [""])[0];
			author = author.toLowerCase().replace(
				// fix names written in all uppercase
				/(?:\s|-|^)([a-zA-ZäöüÄÖÜß])/g,
				function(i) { return i.toUpperCase(); }
			);
			author = (author ? "|Autor=" + author : "");
			
			// --- PAGE TITLE --- //
			var title = "";
			switch(site) {
				case "Bild":
					title = getText(html.querySelector(
						"article header .headline"
					), false);
					break;
				case "FAZ":
					if(urlObj.hostname === "blogs.faz.net") {
						title = getText(html.querySelector(
							"header h2.entry-title"
						), false);
					} else {
						title = getText(html.querySelector(
							"article header h2 .atc-HeadlineText"
						), false);
					}
					break;
				case "Spiegel":
					title = getText(html.querySelector(
						"article header span.align-middle"
					), false);
					break;
				case "Focus":
				case "Merkur":
				case "NZZ":
				case "Stern":
				case "Süddeutsche":
				case "Tagesspiegel":
					title = getText(html.querySelector(
						"meta[property='og:title']"
					), true);
					if(site === "NZZ") { title = title.replace(/ - NZZ$/, ""); }
					break;
				case "taz":
					if(urlObj.hostname === "blogs.taz.de") {
						title = getText(html.querySelector(
							"meta[property='og:title']"
						), true);
					} else {
						title = getText(html.querySelector(
							"article h1 span:last-child"
						), false);
					}
					break;
				case "Welt":
					title = getText(html.querySelector(
						"article header h2"
					), false);
					break;
			}
			title = "|Titel=" + (title ? title : "xxx");
			
			// --- PUBLICATION DATE --- //
			var dateDefault = true;
			var dateOfPub = html.querySelector(
				"meta[property='article:published_time'], meta[name='date']"
			);
			dateOfPub = (dateOfPub ? dateOfPub.getAttribute("content") : "");
			if(!dateOfPub) {
				switch(site) {
					case "Bild":
						dateOfPub = html.querySelector("time.authors__pubdate");
						break;
					case "FAZ":
						dateOfPub = html.querySelector("time.atc-MetaTime");
						break;
					case "Spiegel":
					case "Süddeutsche":
						dateOfPub = html.querySelector("article header time");
						break;
					case "Tagesspiegel":
						dateOfPub = html.querySelector("time[itemprop='datePublished']");
						break;
					case "taz":
						if(urlObj.hostname === "blogs.taz.de") {
							dateOfPub = html.querySelector(
								"p.author em:last-child"
							).textContent;
							dateOfPub = dateOfPub.match(
								/^([0-9]{2})\.([0-9]{2})\.([0-9]{4})/
							) || "";
							if(dateOfPub) {
								dateOfPub =
									"|Tag=" + dateOfPub[1] +
									"|Monat=" + dateOfPub[2] +
									"|Jahr=" + dateOfPub[3];
							}
							dateDefault = false;
						}
						break;
				}
				if(dateDefault) {
					dateOfPub = (dateOfPub ? dateOfPub.getAttribute("datetime") : "");
				}
			}
			if(dateDefault) {
				dateOfPub = dateOfPub.match(
					/^([0-9]{4})-([0-9]{2})-([0-9]{2})/
				) || "";
				if(dateOfPub) {
					dateOfPub =
						"|Tag=" + dateOfPub[3] +
						"|Monat=" + dateOfPub[2] +
						"|Jahr=" + dateOfPub[1];
				}
			}
			
			// --- DATE OF ACCESS --- //
			var dateOfAccess = new Date();
			dateOfAccess = "|Zugriff=" +
				dateOfAccess.getFullYear() + "-" +
				String(dateOfAccess.getMonth() + 1).padStart(2, "0") + "-" +
				String(dateOfAccess.getDate()).padStart(2, "0");
			
			// --- DONE --- //
			var output =
				exampleSentence +
				"<ref>{{Per-" + site + " Online" +
				link + author + title + dateOfPub + dateOfAccess +
				"}}</ref>";
			sendResponse({ state: "success", data: output });
		}
	}
})();
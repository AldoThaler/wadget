(function() {
	"use strict";
	
	var autoCiteState = false,
		autoCiteLink = false,
		autoCiteQuery = false;
	
	chrome.runtime.onMessage.addListener(
		function(request, sender, sendResponse) {
			if(request.action === "getOutput") {
				if(autoCiteState) {
					autoCite(sendResponse);
				} else {
					chrome.tabs.query(
						{ active: true, lastFocusedWindow: true },
						function(tabs) {
							var url = tabs[0].url;
							if(url.startsWith("https://") || url.startsWith("http://")) {
								var urlObj = new URL(tabs[0].url);
								if(urlObj.hostname.includes("books.google")) {
									book(sendResponse, urlObj);
								} else {
									newspaper(sendResponse, urlObj);
								}
							} else { sendResponse(""); }
						}
					);
				}
				return true;
			}
		}
	);
	
	// ------------ //
	// --- BOOK --- //
	// ------------ //
	
	function book(sendResponse, urlObj) {
		var bookId = urlObj.searchParams.get("id");
		fetch("https://www.googleapis.com/books/v1/volumes/" + bookId)
			.then(function(response) { return response.json(); })
			.then(function(response) {
				// --- BOOK DETAILS --- //
				var author = (response.volumeInfo.authors || []).join(", ");
				var title = response.volumeInfo.title.replace(/\|/g, "-");
				var publisher = (response.volumeInfo.publisher || "").replace(/\|/g, "-");
				var dateOfPub = (response.volumeInfo.publishedDate || "")
					.match(/^[0-9]{4}/) || "";
				if(dateOfPub) { dateOfPub = dateOfPub[0]; }
				
				// --- ISBN --- //
				function hyphenateISBN(isbn) {
					var prefix = "";
					if(isbn.length === 13) {
						prefix = isbn.substring(0, 3) + "-";
						isbn = isbn.substring(3, 13);
					}
					
					if(parseInt(isbn.substring(0, 1)) === 3) {
						var regex, d = parseInt(isbn.substring(1, 3));
						if(d < 20) {
							regex = /([0-9])([0-9]{2})([0-9]{6})(\w)/;
						} else if(d < 70) {
							regex = /([0-9])([0-9]{3})([0-9]{5})(\w)/;
						} else if(d < 85) {
							regex = /([0-9])([0-9]{4})([0-9]{4})(\w)/;
						} else if(d < 90) {
							regex = /([0-9])([0-9]{5})([0-9]{3})(\w)/;
						} else if(d < 95) {
							regex = /([0-9])([0-9]{6})([0-9]{2})(\w)/;
						} else if(d <= 99) {
							regex = /([0-9])([0-9]{7})([0-9])(\w)/;
						}
						
						if(regex) {
							isbn = prefix + isbn.replace(regex, "$1-$2-$3-$4");
						}
						return isbn;
					}
					return false;
				}
				var isbn = response.volumeInfo.industryIdentifiers || "";
				if(isbn) {
					if(isbn[0].type === "ISBN_13") {
						isbn = hyphenateISBN(isbn[0].identifier);
					} else if(isbn[1] && isbn[1].type === "ISBN_13") {
						isbn = hyphenateISBN(isbn[1].identifier);
					} else { isbn = ""; }
				}
				
				// --- PAGE NUMBER --- //
				var pageUrl = urlObj.searchParams.get("pg"), pageNum;
				if(!pageUrl) {
					chrome.tabs.executeScript({
						code: "document.all[0].outerHTML"
					}, function(data) {
						var html = new DOMParser().parseFromString(data[0], "text/html");
						var matches = html.getElementById("search_v")
							.querySelectorAll(".sitb-content");
						if(matches.length === 1) {
							pageNum = matches[0].querySelector("h4").innerHTML;
							pageNum = (pageNum.match(/[0-9]+/) || ["xxx"])[0];
							pageUrl = false;
						} else { pageUrl = "xxx"; pageNum = "xxx"; }
						done();
					});
				} else {
					pageNum = (pageUrl.match(/(?<!RA)[0-9]+/) || ["xxx"])[0];
					done();
				}
				
				function done() {
					// --- DONE --- //
					var output =
						"„xxx“" +
						"<ref>{{Literatur" +
						(author ? "|Autor=" + author : "") +
						"|Titel=" + title +
						(publisher ? "|Verlag=" + publisher : "") +
						(dateOfPub ? "|Jahr=" + dateOfPub : "") +
						"|Seiten=" + pageNum +
						(isbn ? "|ISBN=" + isbn : "") +
						"|Online=Zitiert nach " +
						"{{GBS|" + bookId +
							(pageUrl ? "|" + pageUrl : "") +
							"|Hervorhebung=\"xxx\"}}" +
						"}}</ref>";
					sendResponse(output);
				}
			}).catch(function(error) {
				sendResponse("Ein Fehler ist aufgetreten.");
				console.log(error);
			});
	}
	
	// ----------------- //
	// --- NEWSPAPER --- //
	// ----------------- //
	
	function newspaper(sendResponse, urlObj) {
		chrome.tabs.executeScript({
			code: "[document.all[0].outerHTML, window.getSelection().toString()]"
		}, function(data) {
			var html = new DOMParser().parseFromString(data[0][0], "text/html");
			var output = citeNewspaper(urlObj, html, data[0][1].trim());
			sendResponse(output);
		});
	}
	
	function citeNewspaper(urlObj, html, exampleSentence, checkedSite) {
		function escapeRegExp(str) {
			return str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
		}
		
		exampleSentence =
			"„" + (exampleSentence || "xxx")
				.replace(/„/g, "‚")
				.replace(/“/g, "‘")
				.replace(/"/g, "'")  + "“";
		if(autoCiteQuery) {
			exampleSentence = 
				exampleSentence.replace(
					new RegExp(escapeRegExp(autoCiteQuery), "g"),
					"''$&''"
				);
		}
		
		// --- WEBSITE/TEMPLATE NAME --- //
		var site = (
			checkedSite === undefined ? 
			checkSite(urlObj.hostname) : checkedSite
		);
		var link = "|Online=" + urlObj.href;
		if(site) {
			function getText(element, metatag) {
				var val;
				if(metatag) {
					val = (element ? element.getAttribute("content") : "");
				} else {
					val = (element ? element.textContent : "");
				}
				val = val.trim().replace(/\|/g, "");
				return val;
			}
			
			// --- AUTHOR --- //
			var author;
			switch(site) {
				case "Bild":
					author = getText(html.querySelector(".authors__name"), false);
					break;
				case "FAZ":
					author = getText(html.querySelector(
						".atc-MetaAuthor, .atc-MetaAuthorLink"
					), false);
					break;
				case "Focus":
					author = getText(html.querySelector(
						"span[itemprop='author'], a[rel='author']"
					), false);
					break;
				case "Merkur":
					author = getText(html.querySelector(
						"meta[property='lp.article:author']"
					), true);
					break;
				case "NZZ":
				case "Spiegel":
				case "Süddeutsche":
				case "taz":
					author = getText(html.querySelector("meta[name='author']"), true);
					break;
				case "Stern":
					author = "";
					break;
				case "Tagesspiegel":
					author = getText(html.querySelector(".ts-author"), false);
					break;
				case "Welt":
					author = getText(html.querySelector(".c-author__by-line"), false);
					author = author.replace(/^Von/, "").trim();
					break;
			}
			author = (author.match(/[a-zA-ZäöüÄÖÜß\-\s]+/, "") || [""])[0];
			author = author.toLowerCase().replace(
				// fix names written in all uppercase
				/(?<=\s|-|^)([a-zA-ZäöüÄÖÜß])/g,
				function(i) { return i.toUpperCase(); }
			);
			author = (author ? "|Autor=" + author : "");
			
			// --- PAGE TITLE --- //
			var title;
			switch(site) {
				case "Bild":
					title = getText(html.querySelector("article header .headline"), false);
					break;
				case "FAZ":
					title = getText(html.querySelector(
						"article header .atc-HeadlineText"), false
					);
					break;
				case "Focus":
					title = getText(html.querySelector(
						"article .articleHead .posMarker_he"
					), false);
					break;
				case "Spiegel":
					title = getText(html.querySelector(
						"article header span.align-middle"
					), false);
					break;
				case "Merkur":
				case "NZZ":
				case "Stern":
				case "Süddeutsche":
				case "Tagesspiegel":
					title = getText(html.querySelector("meta[property='og:title']"), true);
					if(site === "NZZ") { title = title.replace(/ *NZZ$/, ""); }
					break;
				case "taz":
					title = getText(html.querySelector("article h1 span:last-child"), false);
					break;
				case "Welt":
					title = getText(html.querySelector("article header h2"), false);
					break;
			}
			title = "|Titel=" + (title ? title : "xxx");
			
			// --- PUBLICATION DATE --- //
			var dateOfPub = html.querySelector(
				"meta[property='article:published_time'], meta[name='date']"
			);
			dateOfPub = (dateOfPub ? dateOfPub.getAttribute("content") : "");
			if(!dateOfPub) {
				switch(site) {
					case "Bild":
						dateOfPub = html.querySelector("time.authors__pubdate");
						break;
					case "FAZ":
						dateOfPub = html.querySelector("time.atc-MetaTime");
						break;
					case "Spiegel":
						dateOfPub = html.querySelector("article header time");
						break;
					case "Süddeutsche":
						dateOfPub = html.querySelector(".sz-article__header > time");
						break;
					case "Tagesspiegel":
						dateOfPub = html.querySelector("time[itemprop='datePublished']");
						break;
				}
				dateOfPub = (dateOfPub ? dateOfPub.getAttribute("datetime") : "");
			}
			
			dateOfPub = dateOfPub.match(/^([0-9]{4})-([0-9]{2})-([0-9]{2})/);
			if(dateOfPub) {
				dateOfPub =
					"|Tag=" + dateOfPub[3] +
					"|Monat=" + dateOfPub[2] +
					"|Jahr=" + dateOfPub[1];
			} else { dateOfPub = "|Tag=xxx|Monat=xxx|Jahr=xxx"; }
			
			// --- DATE OF ACCESS --- //
			var dateOfAccess = new Date();
			dateOfAccess = "|Zugriff=" +
				dateOfAccess.getFullYear() + "-" +
				String(dateOfAccess.getMonth() + 1).padStart(2, "0") + "-" +
				String(dateOfAccess.getDate()).padStart(2, "0");
			
			// --- DONE --- //
			var output =
				exampleSentence +
				"<ref>{{Per-" + site + " Online" +
				link + author + title + dateOfPub + dateOfAccess +
				"}}</ref>";
			return output;
		}
		return (
			"Diese Seite wird von Wadget leider nicht anerkannt. " +
			"Nur aus folgenden Online-Zeitungen kannst Du zitieren: " +
			"Bild, FAZ, Focus, Merkur, NZZ, Spiegel, Stern, " +
			"Süddeutsche, Tagesspiegel, taz, Welt"
		);
	}
	
	function checkSite(site) {
		var recognized = false;
		var siteNames = {
			"sueddeutsche.de": "Süddeutsche",
			"tagesspiegel.de": "Tagesspiegel",
			"spiegel.de": "Spiegel",
			"merkur.de": "Merkur",
			"focus.de": "Focus",
			"stern.de": "Stern",
			"bild.de": "Bild",
			"welt.de": "Welt",
			"faz.net": "FAZ",
			"nzz.ch": "NZZ",
			"taz.de": "taz"
		};
		for(let i in siteNames) {
			if(site.includes(i)) {
				site = siteNames[i];
				recognized = true;
				break;
			}
		}
		if(!recognized) { site = false; }
		
		return site;
	}
	
	// ----------------- //
	// --- AUTO CITE --- //
	// --- NEWSPAPERS -- //
	// ----------------- //
	
	chrome.runtime.onInstalled.addListener(function() {
		chrome.contextMenus.create({
			"id": "auto-cite",
			"title": "Seite zitieren",
			"contexts": ["link"]
		});
		chrome.contextMenus.create({
			"id": "auto-cite-query",
			"title": "Suchbegriff markieren",
			"contexts": ["selection"]
		});
	});
	chrome.contextMenus.onClicked.addListener(function(info) {
		if(info.menuItemId === "auto-cite") {
			autoCiteState = true;
			autoCiteLink = info.linkUrl;
		} else if(info.menuItemId === "auto-cite-query") {
			autoCiteQuery = info.selectionText;
		}
	});
	
	function autoCite(sendResponse) {
		var urlObj = new URL(autoCiteLink);
		var site = checkSite(urlObj.hostname);
		if(site) {
			fetch(autoCiteLink)
				.then(function(data) {
					return data.text();
				}).then(function(data) {
					var html = new DOMParser().parseFromString(data, "text/html");
					if(autoCiteQuery) {
						// fetch all paragraphs
						var paragraphs = html.getElementsByTagName("p");
						var text = "";
						for(let i = 0; i < paragraphs.length; i++) {
							var content = paragraphs[i].textContent;
							if(content.length > 50) {
								text += paragraphs[i].textContent.trim() + " ";
							}
						}
						text = text.replace(/[\r\n]/g, " ");
						
						// fetch sentence containing the query
						var sentences = text.match(new RegExp(
							"(?:[A-ZÄÖÜ][^.!?]*|\\b)(?<!-)" + autoCiteQuery +
							"(?!-|[a-zäöü]).*?[.!?]", "g"
						));
						
						if(sentences) {
							// choose any from the list
							var exampleSentence = sentences[
								Math.floor(Math.random() * sentences.length)
							];
							
							var output = citeNewspaper(urlObj, html, exampleSentence, site);
							sendResponse(output);
						} else {
							sendResponse(
								"Der Suchbegriff konnte auf der " +
								"Seite leider nicht gefunden werden."
							);
						}
					} else {
						var output = citeNewspaper(urlObj, html);
						sendResponse(output);
					}
					autoCiteState = false;
				}).catch(function(error) {
					sendResponse("Ein Fehler ist aufgetreten.");
					autoCiteState = false;
					console.log(error);
				});
		} else {
			sendResponse(
				"Diese Seite wird von Wadget leider nicht anerkannt. " +
				"Nur aus folgenden Online-Zeitungen kannst Du zitieren: " +
				"Bild, FAZ, Focus, Merkur, NZZ, Spiegel, Stern, " +
				"Süddeutsche, Tagesspiegel, taz, Welt"
			);
			autoCiteState = false;
		}
	}
})();
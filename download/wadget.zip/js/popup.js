(function() {
	"use strict";
	
	// copy to clipboard
	document.getElementById("copy").addEventListener("click", function() {
		document.getElementById("output").select();
		document.execCommand("copy");
	});

	// convert images to inline SVGs
	var svgList = document.querySelectorAll("img[src$='.svg']");
	for(let i = 0; i < svgList.length; i++) {
		var img = svgList[i];
		(function(img) {
			var xhr = new XMLHttpRequest();
			xhr.onreadystatechange = function() {
				if(this.readyState === 4) {
					var svg = new DOMParser()
						.parseFromString(xhr.responseText, "text/xml")
						.firstChild;
					var img_id = img.getAttribute("id");
					var img_class = img.getAttribute("class");
					var img_height = img.getAttribute("height");
					var img_width = img.getAttribute("width");
					
					if(img_id) { svg.setAttribute("id", img_id); }
					if(img_class) { svg.setAttribute("class", img_class); }
					if(img_height) { svg.setAttribute("height", img_height); }
					if(img_width) { svg.setAttribute("width", img_width); }
					
					img.parentNode.replaceChild(svg, img);
				}
			}
			xhr.open("GET", img.getAttribute("src"));
			xhr.send();
		})(img);
	}
	
	// turn off spellcheck
	document.querySelectorAll("input[type='text'], textarea")
		.forEach(function(element) {
			element.spellcheck = false;
		}
	);
	
	// request output when popup is opened
	document.getElementById("output").value = "Bitte warten…";
	chrome.runtime.sendMessage({ action: "getOutput" }, function(response) {
		document.getElementById("output").value = response.data;
	});
})();